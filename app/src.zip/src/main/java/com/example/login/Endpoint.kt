package com.example.login


import retrofit2.http.GET
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

interface Endpoint {
    @GET("parkings/getall")
    suspend fun getDogs(): Response<List<Parking>>

    companion object {
        private var endpoint: Endpoint? = null

        fun create(): Endpoint {
            if (endpoint == null) {
                endpoint = Retrofit.Builder()
                    .baseUrl("https://95a7-154-121-24-52.ngrok-free.app/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                    .create(Endpoint::class.java)
            }
            return endpoint!!
        }
    }
}
