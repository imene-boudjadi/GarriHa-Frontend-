import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.rememberNavController
import com.example.login.Parking
import com.example.login.UserDatabase
import com.example.login.ui.theme.LoginTheme
import com.example.parkir.views.router.NavigationHost
import com.example.parkir.views.router.Router
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val context = LocalContext.current

            LoginTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    // Récupération des parkings depuis la base de données dans un bloc de coroutine
                    var parkings by remember { mutableStateOf<List<Parking>>(emptyList()) }

                    LaunchedEffect(key1 = context) {
                        parkings = fetchDataFromDatabase(context)
                    }

                    // Affichage de la liste des parkings
                    DisplayParkings(parkings = parkings)
                }
            }
        }
    }

    private suspend fun fetchDataFromDatabase(context: Context): List<Parking> {
        return withContext(Dispatchers.IO) {
            UserDatabase.getDatabase(context).getParkingDao().getAllParkings()
        }
    }
}

@Composable
fun DisplayParkings(parkings: List<Parking>) {
    // Affichage de la liste des parkings ici
    // Utilisez la fonction DisplayParkings fournie dans ListParkings.kt
    DisplayParkings(parkings = parkings)
}

@Preview(showBackground = true)
@Composable
fun PreviewDisplayParkings() {
    val sampleParkings = listOf(
        Parking(parkingId = 1, parkingName = "Parking 1", DescriptionParking = "Description 1"),
        Parking(parkingId = 2, parkingName = "Parking 2", DescriptionParking = "Description 2")
    )
    DisplayParkings(parkings = sampleParkings)
}
